import React from "react";
function Footer()
{
  return(
    
      <footer>
        <p>copyrights by shapeAI @{new Date().getFullYear()}</p>
      </footer>
      
      
    
  );
}
export default Footer;