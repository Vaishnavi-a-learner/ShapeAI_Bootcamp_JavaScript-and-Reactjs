import React from "react";
function Header()
{
  return(
    <div>
      <header>
      <h1><center>Shape AI Bootcamps </center></h1>
      </header>
      </div>
  );
}
export default Header;